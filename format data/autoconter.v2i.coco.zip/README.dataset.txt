# autoconter > 2024-12-16 11:23am
https://universe.roboflow.com/autocounter-object-detection/autoconter

Provided by a Roboflow user
License: CC BY 4.0

